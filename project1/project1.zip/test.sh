#! osh
echo x
pwd
